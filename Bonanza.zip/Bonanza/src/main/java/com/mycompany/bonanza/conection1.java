/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.bonanza;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author angel
 */
public class conection1 {
     Connection con;
    public conection1(){ //este es el constructor para hacer la conexion a la base de datos de inmediato 
    
    
        try {
            Class.forName("com.mysql.jdbc.Driver"); //Nombra la ruta donde voy a conectarme, el driver es la clase propia a la que quiero conectarme y JDBC ES JAVA DATA BASE CONNECTIVITY
            try {
                con= (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/bdconekta","root",""); // El "con" ayuda a la conexion de la base de datos, viene siendo una variable y el 3306 es el puerto al que se conecta XAMMP
            } catch (SQLException ex) {
                Logger.getLogger(conection1.class.getName()).log(Level.SEVERE, null, ex);
            }
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(conection1.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
